
# BoxOfficeIQ India

## Indian Cinema Revenue Intelligence

### Day 08 Data Science Portfolio Project

**Case Study:** Namit Malhotra's Ramayana

## Project Overview

BoxOfficeIQ India is a machine learning and analytics
prototype that studies Indian movie financial performance.

It explores the relationship between production budgets,
release timing, film industries, languages, genres and
worldwide box-office collections.

The project also includes an experimental Ramayana
scenario simulator.

## Dataset

Indian Movies Box Office Collection (2014-2024)

Source:
https://github.com/arvindbadagi/Indian-Movies-Box-Office-Collection

Currency: INR Crores

## Dataset Statistics

- Original records: 604
- Cleaned records: 602
- Training records: 481
- Testing records: 121

## Machine Learning Models

- Ridge Regression
- Random Forest Regressor
- Extra Trees Regressor

## Best Model

Ridge Regression

## Model Evaluation

           Model  MAE_Crore  RMSE_Crore  R2_Score
Ridge Regression  50.556418   92.997458  0.529048
     Extra Trees  59.637779  110.860917  0.330745
   Random Forest  61.280261  114.716013  0.283390

## Features

- Data acquisition
- Data cleaning
- Exploratory data analysis
- Financial analysis
- Feature engineering
- Categorical encoding
- Regression modelling
- Chronological evaluation
- Feature importance
- Scenario analysis
- Budget sensitivity analysis

## Ramayana Case Study

The Ramayana simulator uses user-provided assumptions
to create an experimental model estimate.

It does not represent actual revenue, confirmed budget,
or a reliable commercial forecast.

## Important Limitations

- The dataset contains a limited number of movies.
- Historical box-office figures may have source limitations.
- The dataset may not cover all Indian film industries equally.
- Worldwide gross is not equivalent to producer profit.
- Future releases may fall outside the training period.
- Model estimates should not be used for investment decisions.

## Technologies

Python, Pandas, NumPy, Matplotlib, Seaborn,
Scikit-learn and Joblib.

## Run

Open the notebook in Google Colab and execute the
complete notebook cell.

The dataset is downloaded automatically.

## Project Type

Educational machine learning prototype.
